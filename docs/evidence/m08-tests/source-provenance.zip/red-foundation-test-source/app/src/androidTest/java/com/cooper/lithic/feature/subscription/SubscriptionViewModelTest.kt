package com.cooper.lithic.feature.subscription

import android.content.Context
import android.os.Bundle
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.viewModelScope
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.cooper.lithic.core.time.FixedBusinessClock
import com.cooper.lithic.data.backup.DataGenerationStore
import com.cooper.lithic.data.backup.ManagedGeneration
import com.cooper.lithic.data.local.LithicDatabase
import com.cooper.lithic.data.repository.SubscriptionRepository
import com.cooper.lithic.domain.subscription.BillingCycle
import com.cooper.lithic.feature.project.LeaveDecision
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Actual Room facts and actual saved task state; no in-memory payment substitute. */
@RunWith(AndroidJUnit4::class)
class SubscriptionViewModelTest {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val clock = FixedBusinessClock(LocalDate.of(2026, 1, 20))
    private val timestamp = Instant.parse("2026-01-20T12:00:00Z")
    private lateinit var root: File
    private lateinit var generation: ManagedGeneration
    private lateinit var repository: SubscriptionRepository
    private val models = mutableListOf<SubscriptionViewModel>()
    private val stores = mutableListOf<ViewModelStore>()

    @Before fun before() = runBlocking {
        root = File(context.noBackupFilesDir, "m08-vm-${UUID.randomUUID()}")
        check(root.mkdir())
        generation = DataGenerationStore(context, root).open(ZoneId.of("Asia/Shanghai"))
        repository = SubscriptionRepository(generation.database, generation.coordinator, clock)
    }

    @After fun after() = runBlocking {
        val jobs = models.mapNotNull { it.viewModelScope.coroutineContext[Job] }
        onMain { stores.forEach { it.clear() } }
        jobs.forEach { it.join() }
        generation.close()
        check(root.canonicalFile.parentFile == context.noBackupFilesDir.canonicalFile)
        check(root.deleteRecursively())
    }

    @Test fun raw_four_dates_and_cycle_survive_saved_state_recreation() = runBlocking {
        val handle = SavedStateHandle()
        val first = vm(handle)
        fillCreate(first, "未保存订阅", "123.456")
        onMain { first.changeCycle(BillingCycle.YEARLY); first.changeNote("准确日期不能被预填覆盖") }
        val restored = vm(restoredHandle(handle))
        assertNotNull("The saved task must restore its original active subscription form", restored.state.value.editor)
        val editor = restored.state.value.editor!!
        assertEquals("未保存订阅", editor.serviceName)
        assertEquals("123.456", editor.amount)
        assertEquals(BillingCycle.YEARLY, editor.cycle)
        assertEquals("2026-01-02", editor.paidOn)
        assertEquals("2026-01-03", editor.effectiveFrom)
        assertEquals("2026-02-03", editor.paidUntilExclusive)
        assertEquals("2026-02-05", editor.reminderDueOn)
        assertEquals("准确日期不能被预填覆盖", editor.note)
        assertEquals(LeaveDecision.CONFIRM_DISCARD, restored.leaveDecision())
        assertEquals(0L, generation.database.subscriptionDao().countSubscriptions())
    }

    @Test fun first_confirmed_payment_persists_identity_and_four_dates() = runBlocking {
        val model = vm()
        fillCreate(model, "真实首付款", "150.00")
        onMain { model.save() }
        await(model) { it.committedSubscriptionId != null }
        val id = model.state.value.committedSubscriptionId!!
        val detail = repository.loadSubscriptionDetail(id)!!
        assertEquals("真实首付款", detail.subscription.name)
        val renewal = detail.renewals.single()
        assertEquals(15000L, renewal.amountCents)
        assertEquals(BillingCycle.MONTHLY, renewal.cycle)
        assertEquals(30, renewal.standardDays)
        assertEquals(LocalDate.of(2026, 1, 2), renewal.paidOn)
        assertEquals(LocalDate.of(2026, 1, 3), renewal.effectiveFrom)
        assertEquals(LocalDate.of(2026, 2, 3), renewal.paidUntilExclusive)
        assertEquals(LocalDate.of(2026, 2, 5), renewal.reminderDueOn)
        onMain { model.save() }
        assertEquals(1L, generation.database.subscriptionDao().countSubscriptions())
        assertEquals(listOf(renewal), repository.loadSubscriptionDetail(id)!!.renewals)
    }

    @Test fun invalid_real_payment_preserves_raw_fields_and_reports_amount_error() = runBlocking {
        val model = vm()
        fillCreate(model, "保留未确认输入", "0")
        onMain { model.save() }
        val editor = model.state.value.editor!!
        assertTrue("Zero cannot be accepted as a real renewal payment", editor.errors.containsKey("amount"))
        assertEquals("0", editor.amount)
        assertEquals("2026-01-02", editor.paidOn)
        assertEquals("2026-01-03", editor.effectiveFrom)
        assertEquals("2026-02-03", editor.paidUntilExclusive)
        assertEquals("2026-02-05", editor.reminderDueOn)
        assertNull(model.state.value.committedSubscriptionId)
        assertEquals(0L, generation.database.subscriptionDao().countSubscriptions())
    }

    @Test fun opening_and_discarding_form_never_creates_a_real_payment() = runBlocking {
        val model = vm()
        onMain { model.startCreate() }
        assertNotNull(model.state.value.editor)
        assertEquals(0L, generation.database.subscriptionDao().countSubscriptions())
        fillCreate(model, "只是填写", "150")
        onMain { model.discardForm() }
        assertNull(model.state.value.editor)
        assertEquals(0L, generation.database.subscriptionDao().countSubscriptions())
        assertEquals(LeaveDecision.ALLOW, model.leaveDecision())
    }

    private fun vm(handle: SavedStateHandle = SavedStateHandle()): SubscriptionViewModel {
        lateinit var model: SubscriptionViewModel
        onMain {
            model = SubscriptionViewModel(repository, handle, clock) { timestamp }
            models += model
            ViewModelStore().also { it.put("subscription", model); stores += it }
        }
        return model
    }

    private fun fillCreate(model: SubscriptionViewModel, name: String, amount: String) {
        onMain {
            model.startCreate()
            model.changeName(name)
            model.changeCategory(LithicDatabase.SUBSCRIPTION_FALLBACK_ID)
            model.changeAmount(amount)
            model.changePaidOn("2026-01-02")
            model.changeEffectiveFrom("2026-01-03")
            model.changePaidUntil("2026-02-03")
            model.changeReminderDue("2026-02-05")
        }
        assertNotNull("The real editor must exist before the confirm action", model.state.value.editor)
    }

    private fun restoredHandle(source: SavedStateHandle): SavedStateHandle = SavedStateHandle(source.keys().associateWith { key ->
        val value = source.get<Any?>(key)
        if (value is Bundle) Bundle(value) else value
    })

    private suspend fun await(model: SubscriptionViewModel, predicate: (SubscriptionUiState) -> Boolean) {
        val result = withTimeoutOrNull(5_000) { model.state.first(predicate) }
        assertNotNull("Expected actual subscription state was not reached: phase=${model.state.value.editor?.phase}", result)
    }

    private fun onMain(action: () -> Unit) = InstrumentationRegistry.getInstrumentation().runOnMainSync(action)
}
