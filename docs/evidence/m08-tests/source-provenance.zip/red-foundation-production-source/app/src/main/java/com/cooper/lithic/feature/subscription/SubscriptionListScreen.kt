package com.cooper.lithic.feature.subscription

import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
internal fun SubscriptionListScreen(
    state: SubscriptionListUiState,
    onBack: () -> Unit,
    onCreate: () -> Unit,
    onOpenSubscription: (String) -> Unit,
    onLoadMore: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier)
}
