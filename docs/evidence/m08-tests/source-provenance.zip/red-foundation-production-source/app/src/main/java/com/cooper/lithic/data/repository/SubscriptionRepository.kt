package com.cooper.lithic.data.repository

import com.cooper.lithic.core.time.BusinessClock
import com.cooper.lithic.data.local.CategoryEntity
import com.cooper.lithic.data.local.LithicDatabase
import java.time.LocalDate
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Non-owning M08 API shell. Repository behavior is implemented after its real RED tests. */
open class SubscriptionRepository(
    private val db: LithicDatabase,
    private val coordinator: LocalWriteCoordinator,
    private val clock: BusinessClock,
) {
    open suspend fun createWithRenewal(command: CreateSubscriptionCommand): SubscriptionMutationResult =
        SubscriptionMutationResult.StorageFailure(StorageFailureKind.DATABASE, "Subscription creation is not implemented")
    open suspend fun confirmRenewal(command: ConfirmRenewalCommand): SubscriptionMutationResult =
        SubscriptionMutationResult.StorageFailure(StorageFailureKind.DATABASE, "Renewal confirmation is not implemented")
    open suspend fun loadSubscriptionDetail(id: String, asOf: LocalDate = clock.today()): SubscriptionDetail? =
        error("Subscription detail reading is not implemented")
    open suspend fun loadSubscriptionPage(cursor: SubscriptionCursor? = null, pageSize: Int = 50, asOf: LocalDate = clock.today()): SubscriptionPage =
        error("Subscription page reading is not implemented")
    open suspend fun loadSubscriptionWindow(pageCount: Int, asOf: LocalDate = clock.today()): SubscriptionPage =
        error("Subscription window reading is not implemented")
    open suspend fun loadRenewalHistory(subscriptionId: String, cursor: RenewalCursor? = null, pageSize: Int = 50, asOf: LocalDate = clock.today()): RenewalHistoryPage =
        error("Renewal history reading is not implemented")
    open suspend fun loadRenewalHistoryWindow(subscriptionId: String, pageCount: Int, asOf: LocalDate = clock.today()): RenewalHistoryPage =
        error("Renewal history window reading is not implemented")
    open suspend fun loadSubscriptionCategories(): List<CategoryEntity> = error("Subscription category reading is not implemented")
    open suspend fun loadSubscriptionCount(): Long = error("Subscription counting is not implemented")
    open val changes: Flow<Unit> = db.invalidationTracker.createFlow(
        "subscriptions", "subscription_renewals", "subscription_state_changes", "categories",
    ).map { Unit }
}
