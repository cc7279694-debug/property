package com.cooper.lithic.feature.subscription

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.cooper.lithic.core.time.BusinessClock
import com.cooper.lithic.data.repository.SubscriptionRepository
import com.cooper.lithic.domain.subscription.BillingCycle
import com.cooper.lithic.feature.project.LeaveDecision
import java.time.Instant
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** M08 TDD shell: persistence and saved-state behavior await actual RED evidence. */
class SubscriptionViewModel(
    private val repository: SubscriptionRepository,
    private val savedState: SavedStateHandle,
    private val clock: BusinessClock,
    private val instant: () -> Instant = Instant::now,
) : ViewModel() {
    private val mutableState = MutableStateFlow(SubscriptionUiState())
    val state: StateFlow<SubscriptionUiState> = mutableState.asStateFlow()
    fun loadList() = Unit
    fun loadMore() = Unit
    fun openDetail(subscriptionId: String) = Unit
    fun loadMoreHistory() = Unit
    fun startCreate() { mutableState.value = state.value.copy(editor = SubscriptionEditorUiState(today = clock.today())) }
    fun startRenewal(subscriptionId: String) { mutableState.value = state.value.copy(editor = SubscriptionEditorUiState(kind = SubscriptionEditorKind.RENEWAL, subscriptionId = subscriptionId, today = clock.today())) }
    private fun change(transform: (SubscriptionEditorUiState) -> SubscriptionEditorUiState) {
        state.value.editor?.let { mutableState.value = state.value.copy(editor = transform(it)) }
    }
    fun changeName(value: String) = change { it.copy(serviceName = value) }
    fun changeCategory(value: String) = change { it.copy(categoryId = value) }
    fun changeNote(value: String) = change { it.copy(note = value) }
    fun changeAmount(value: String) = change { it.copy(amount = value) }
    fun changeCycle(value: BillingCycle) = change { it.copy(cycle = value) }
    fun changePaidOn(value: String) = change { it.copy(paidOn = value) }
    fun changeEffectiveFrom(value: String) = change { it.copy(effectiveFrom = value) }
    fun changePaidUntil(value: String) = change { it.copy(paidUntilExclusive = value) }
    fun changeReminderDue(value: String) = change { it.copy(reminderDueOn = value) }
    fun save() = Unit
    fun retryRead() = Unit
    fun refresh() = Unit
    fun discardForm() { mutableState.value = state.value.copy(editor = null) }
    fun leaveDecision(): LeaveDecision = LeaveDecision.ALLOW
    fun consumeCommitted() = Unit
}
