package com.cooper.lithic.app

import com.cooper.lithic.feature.project.LeaveDecision

/** M08 TDD shell; existing project navigation remains untouched until verified integration. */
internal fun globalLeaveDecision(projectDecision: LeaveDecision, subscriptionDecision: LeaveDecision): LeaveDecision =
    LeaveDecision.ALLOW
