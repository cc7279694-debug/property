package com.cooper.lithic.feature.subscription

import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.cooper.lithic.domain.subscription.BillingCycle

@Composable
internal fun RenewalEditorScreen(
    state: SubscriptionEditorUiState,
    onBack: () -> Unit,
    onAmountChange: (String) -> Unit,
    onCycleChange: (BillingCycle) -> Unit,
    onPaidOnChange: (String) -> Unit,
    onEffectiveFromChange: (String) -> Unit,
    onPaidUntilChange: (String) -> Unit,
    onReminderDueChange: (String) -> Unit,
    onConfirmPayment: () -> Unit,
    onRetryRead: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier)
}
