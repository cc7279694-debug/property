package com.cooper.lithic.feature.media

import android.content.Context
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.cooper.lithic.core.model.MoneyDirection
import com.cooper.lithic.core.time.FixedBusinessClock
import com.cooper.lithic.data.backup.DataGenerationStore
import com.cooper.lithic.data.backup.ManagedGeneration
import com.cooper.lithic.data.local.LithicDatabase
import com.cooper.lithic.data.local.LongTermProjectEntity
import com.cooper.lithic.data.local.ProjectMoneyEventEntity
import com.cooper.lithic.data.local.ProjectMoneyEventRole
import com.cooper.lithic.data.local.SubscriptionEntity
import com.cooper.lithic.data.local.SubscriptionRenewalEntity
import com.cooper.lithic.data.media.CoverTarget
import com.cooper.lithic.data.media.CoverTargetType
import com.cooper.lithic.data.media.LocalImageStore
import com.cooper.lithic.data.media.MediaRepository
import com.cooper.lithic.domain.subscription.BillingCycle
import com.cooper.lithic.feature.project.LeaveDecision
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Task-state consumers read actual generation facts and cannot invent a second image owner. */
@RunWith(AndroidJUnit4::class)
class M10CoverViewModelTest {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val clock = FixedBusinessClock(LocalDate.of(2026, 1, 25))
    private val timestamp = Instant.parse("2026-01-25T12:00:00Z")
    private val models = ViewModelStore()
    private val jobs = mutableListOf<Job>()
    private lateinit var root: File
    private lateinit var generation: ManagedGeneration
    private lateinit var repository: MediaRepository

    @Before fun before() = runBlocking {
        root = File(context.noBackupFilesDir, "m10-cover-vm-${UUID.randomUUID()}")
        check(root.mkdir())
        generation = DataGenerationStore(context, root).open(ZoneId.of("Asia/Shanghai"))
        repository = MediaRepository(generation.database, generation.coordinator,
            LocalImageStore(generation.directory), clock, context.contentResolver)
    }

    @After fun after() = runBlocking {
        onMain { models.clear() }; jobs.forEach { it.join() }
        generation.close()
        check(root.canonicalFile.parentFile == context.noBackupFilesDir.canonicalFile)
        check(root.deleteRecursively())
    }

    @Test fun project_cover_editor_retains_real_identity_and_history_origin_without_writing() = runBlocking {
        val project = seedProject()
        val model = model()
        onMain { model.start(CoverTarget(CoverTargetType.PROJECT, project.id), "HISTORY") }
        assertNotNull("Opening a real project's cover must produce a recoverable editor", model.state.value.editor)
        val editor = withTimeout(15_000) { model.state.first { it.editor?.loading == false } }.editor!!
        assertEquals(CoverTarget(CoverTargetType.PROJECT, project.id), editor.target)
        assertEquals("HISTORY", editor.origin)
        assertEquals(project.name, editor.name)
        assertEquals(project, generation.database.projectDao().findProject(project.id))
        assertTrue(generation.database.mediaDao().list().isEmpty())
        assertEquals(LeaveDecision.ALLOW, model.leaveDecision())
    }

    @Test fun subscription_cover_editor_retains_identity_and_real_payment_without_writing() = runBlocking {
        val subscription = seedSubscription()
        val before = generation.database.subscriptionDao().renewalsForSubscriptions(listOf(subscription.id))
        val model = model()
        onMain { model.start(CoverTarget(CoverTargetType.SUBSCRIPTION, subscription.id)) }
        assertNotNull("Opening a real subscription's cover must produce a recoverable editor", model.state.value.editor)
        val editor = withTimeout(15_000) { model.state.first { it.editor?.loading == false } }.editor!!
        assertEquals(subscription.id, editor.target.id)
        assertEquals(subscription.name, editor.name)
        assertEquals(subscription, generation.database.subscriptionDao().findSubscription(subscription.id))
        assertEquals(before, generation.database.subscriptionDao().renewalsForSubscriptions(listOf(subscription.id)))
        assertTrue(generation.database.mediaDao().list().isEmpty())
    }

    @Test fun system_picker_cancel_does_not_dirty_or_write_project_or_media() = runBlocking {
        val project = seedProject()
        val beforeEvents = generation.database.projectDao().eventsForProjects(listOf(project.id))
        val model = model()
        onMain { model.start(CoverTarget(CoverTargetType.PROJECT, project.id)) }
        assertNotNull("Picker cancellation must be handled by the formal cover editor", model.state.value.editor)
        withTimeout(15_000) { model.state.first { it.editor?.loading == false } }
        onMain { model.chooseImage(null) }
        assertNull(model.state.value.editor!!.preparedAsset)
        assertEquals(LeaveDecision.ALLOW, model.leaveDecision())
        assertEquals(project, generation.database.projectDao().findProject(project.id))
        assertEquals(beforeEvents, generation.database.projectDao().eventsForProjects(listOf(project.id)))
        assertTrue(generation.database.mediaDao().list().isEmpty())
    }

    private suspend fun seedProject(): LongTermProjectEntity {
        val project = LongTermProjectEntity(UUID.randomUUID().toString(), "合成项目封面", LithicDatabase.PROJECT_FALLBACK_ID,
            LocalDate.of(2026, 1, 1), note = "原项目备注", createdAt = timestamp, updatedAt = timestamp)
        generation.coordinator.withWrite {
            generation.database.withTransaction {
                generation.database.projectDao().insertProject(project)
                generation.database.projectDao().insertEvent(ProjectMoneyEventEntity(UUID.randomUUID().toString(), project.id,
                    MoneyDirection.OUTLAY, 15000, LocalDate.of(2026, 1, 1), "原真实初始付款",
                    ProjectMoneyEventRole.INITIAL, UUID.randomUUID().toString()))
            }
        }
        return project
    }

    private suspend fun seedSubscription(): SubscriptionEntity {
        val subscription = SubscriptionEntity(UUID.randomUUID().toString(), "合成订阅封面", LithicDatabase.SUBSCRIPTION_FALLBACK_ID,
            note = "原订阅备注", createdAt = timestamp, updatedAt = timestamp)
        generation.coordinator.withWrite {
            generation.database.withTransaction {
                generation.database.subscriptionDao().insertSubscription(subscription)
                generation.database.subscriptionDao().insertRenewal(SubscriptionRenewalEntity(UUID.randomUUID().toString(), subscription.id,
                    LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 1), LocalDate.of(2026, 2, 1), LocalDate.of(2026, 1, 29),
                    15000, BillingCycle.MONTHLY, 30, UUID.randomUUID().toString()))
            }
        }
        return subscription
    }

    private fun model(handle: SavedStateHandle = SavedStateHandle()): CoverViewModel {
        lateinit var model: CoverViewModel
        onMain {
            model = CoverViewModel(repository, handle) { timestamp.plusNanos(1) }
            models.put("cover-${UUID.randomUUID()}", model)
            model.viewModelScope.coroutineContext[Job]?.let(jobs::add)
        }
        return model
    }

    private fun onMain(block: () -> Unit) = InstrumentationRegistry.getInstrumentation().runOnMainSync(block)
}
