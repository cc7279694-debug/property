package com.cooper.lithic.data.media

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File
import java.io.FileNotFoundException
import java.util.UUID

/** Test APK only: read-only synthetic streams, never real user images. */
class M10ImageSourceProvider : ContentProvider() {
    override fun onCreate() = true
    override fun getType(uri: Uri): String = uri.getQueryParameter("mime") ?: "image/png"
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode != "r") throw FileNotFoundException("Synthetic source is read-only")
        return ParcelFileDescriptor.open(source(uri), ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val file = source(uri)
        return MatrixCursor(arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)).apply { addRow(arrayOf(file.name, file.length())) }
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
    private fun source(uri: Uri): File {
        val name = uri.lastPathSegment ?: throw FileNotFoundException("Missing synthetic source")
        if (!name.matches(Regex("[a-f0-9-]{36}\\.bin"))) throw FileNotFoundException("Invalid synthetic source")
        return File(File(requireNotNull(context).cacheDir, "m10-synthetic-image-sources"), name)
    }
}

data class SyntheticImageSource(val file: File, val uri: Uri)

object M10ImageSourceFixtures {
    fun source(bytes: ByteArray, mime: String = "image/png"): SyntheticImageSource {
        val context = InstrumentationRegistry.getInstrumentation().context
        val root = File(context.cacheDir, "m10-synthetic-image-sources").apply { mkdirs() }
        val file = File(root, "${UUID.randomUUID()}.bin").apply { writeBytes(bytes) }
        val uri = Uri.Builder().scheme("content").authority("com.cooper.lithic.m10.testsource").appendPath(file.name).appendQueryParameter("mime", mime).build()
        return SyntheticImageSource(file, uri)
    }
}
