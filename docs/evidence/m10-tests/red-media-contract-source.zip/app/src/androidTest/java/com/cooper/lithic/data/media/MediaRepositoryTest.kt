package com.cooper.lithic.data.media

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.cooper.lithic.core.model.MoneyDirection
import com.cooper.lithic.core.time.FixedBusinessClock
import com.cooper.lithic.data.backup.DataGenerationStore
import com.cooper.lithic.data.backup.ManagedGeneration
import com.cooper.lithic.data.local.CategoryType
import com.cooper.lithic.data.local.LocalMediaAssetEntity
import com.cooper.lithic.data.local.LongTermProjectEntity
import com.cooper.lithic.data.local.ProjectMoneyEventEntity
import com.cooper.lithic.data.local.ProjectMoneyEventRole
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Real private generation/SQLite tests, with isolated synthetic facts only. */
@RunWith(AndroidJUnit4::class)
class MediaRepositoryTest {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private lateinit var root: File
    private lateinit var generation: ManagedGeneration
    private lateinit var images: LocalImageStore
    private lateinit var repository: MediaRepository
    private val date = LocalDate.of(2026, 1, 31)
    private val time = Instant.parse("2026-01-31T03:04:05Z")

    @Before fun setUp() = runBlocking {
        root = File(context.noBackupFilesDir, "m10-repository-${UUID.randomUUID()}")
        generation = DataGenerationStore(context, root).open(ZoneId.of("UTC"))
        images = LocalImageStore(generation.directory)
        repository = MediaRepository(generation.database, generation.coordinator, images, FixedBusinessClock(date), context.contentResolver)
    }

    @After fun tearDown() = runBlocking {
        if (::generation.isInitialized) generation.close()
        if (::root.isInitialized) {
            check(root.canonicalFile.parentFile == context.noBackupFilesDir.canonicalFile)
            root.deleteRecursively()
        }
    }

    // Dropping money events from the editor baseline would permit stale cover writes.
    @Test fun load_target_returns_complete_project_and_money_facts() = runBlocking {
        val expected = project()
        val loaded = repository.loadTarget(expected.target)
        assertTrue("Expected the real project baseline, got $loaded", loaded is MediaResult.Success)
        assertEquals(expected, (loaded as MediaResult.Success<CoverBaseline>).value)
        assertEquals(15_000L, (loaded.value as CoverBaseline.Project).events.single().amountCents)
    }

    // Cover removal must write only its reference and revision, including a missing old image.
    @Test fun remove_cover_keeps_original_money_and_identity() = runBlocking {
        val old = metadata()
        generation.database.mediaDao().insert(old)
        val expected = project(old.id)
        val command = CoverCommand(uuid(), expected, null, time.plusSeconds(1))
        val result = repository.commit(command)
        assertTrue("Expected successful cover removal, got $result", result is MediaResult.Success)
        val actual = generation.database.projectDao().findProject(expected.project.id)
        assertEquals(expected.project.copy(coverAssetId = null, updatedAt = time.plusSeconds(1)), actual)
        assertEquals(expected.events, generation.database.projectDao().eventsForProjects(listOf(expected.project.id)))
        assertNotNull(generation.database.mediaDao().find(old.id))
    }

    private suspend fun project(coverId: String? = null): CoverBaseline.Project {
        val category = generation.database.categoryDao().list().single { it.type == CategoryType.PROJECT }
        val item = LongTermProjectEntity(uuid(), "Synthetic M10 project", category.id, LocalDate.of(2026, 1, 1),
            coverAssetId = coverId, note = "Keep this original note", createdAt = time, updatedAt = time)
        val event = ProjectMoneyEventEntity(uuid(), item.id, MoneyDirection.OUTLAY, 15_000,
            LocalDate.of(2026, 1, 1), "actual initial payment", ProjectMoneyEventRole.INITIAL, uuid())
        generation.database.projectDao().insertProject(item)
        generation.database.projectDao().insertEvent(event)
        return CoverBaseline.Project(item, listOf(event))
    }

    private fun metadata(): LocalMediaAssetEntity {
        val id = uuid()
        return LocalMediaAssetEntity(id, "media/$id.png", "image/png", 1, 1, 1, "0".repeat(64))
    }
    private fun uuid() = UUID.randomUUID().toString()
}
