package com.cooper.lithic.feature.media

import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.cooper.lithic.data.local.LocalMediaAssetEntity
import com.cooper.lithic.data.media.CoverTarget
import com.cooper.lithic.data.media.MediaRepository
import com.cooper.lithic.feature.project.LeaveDecision
import com.cooper.lithic.feature.project.SubmissionPhase
import java.time.Instant
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CoverEditorUiState(
    val target: CoverTarget,
    val origin: String,
    val name: String = "",
    val oldAssetId: String? = null,
    val preparedAsset: LocalMediaAssetEntity? = null,
    val remove: Boolean = false,
    val loading: Boolean = false,
    val preparing: Boolean = false,
    val phase: SubmissionPhase = SubmissionPhase.IDLE,
    val dirty: Boolean = false,
    val message: String? = null,
    val conflict: Boolean = false,
    val missing: Boolean = false,
)

data class CoverUiState(
    val editor: CoverEditorUiState? = null,
    val committedTarget: CoverTarget? = null,
    val committedOrigin: String = "CURRENT",
)

/** The compileable missing behavior API used for the initial M10 behavior RED. */
class CoverViewModel(
    private val repository: MediaRepository,
    private val savedState: SavedStateHandle,
    private val instant: () -> Instant = Instant::now,
) : ViewModel() {
    private val mutableState = MutableStateFlow(CoverUiState())
    val state: StateFlow<CoverUiState> = mutableState.asStateFlow()
    fun start(target: CoverTarget, origin: String = "CURRENT") = Unit
    fun chooseImage(uri: Uri?) = Unit
    fun removeCover() = Unit
    fun save() = Unit
    fun retryRead() = Unit
    fun consumeCommitted() = Unit
    fun discardForm() = Unit
    fun leaveDecision(): LeaveDecision = LeaveDecision.ALLOW
}
