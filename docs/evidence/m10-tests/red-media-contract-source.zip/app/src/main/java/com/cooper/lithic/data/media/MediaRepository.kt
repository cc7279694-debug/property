package com.cooper.lithic.data.media

import android.content.ContentResolver
import android.net.Uri
import com.cooper.lithic.core.time.BusinessClock
import com.cooper.lithic.data.local.LithicDatabase
import com.cooper.lithic.data.repository.LocalWriteCoordinator

/** Non-owning facade over the current generation; initial M10 behavior RED seam. */
open class MediaRepository(
    private val database: LithicDatabase,
    private val coordinator: LocalWriteCoordinator,
    private val images: LocalImageStore,
    private val clock: BusinessClock,
    private val resolver: ContentResolver,
) {
    open suspend fun loadTarget(target: CoverTarget): MediaResult<CoverBaseline> = missing()
    open suspend fun prepareImport(uri: Uri, assetId: String): MediaResult<PreparedImage> = missing()
    open suspend fun restorePrepared(assetId: String): MediaResult<PreparedImage> = missing()
    open suspend fun discardPrepared(assetId: String): MediaResult<Boolean> = missing()
    open suspend fun commit(command: CoverCommand): MediaResult<CoverCommitOutcome> = missing()
    open suspend fun verifyCommitted(command: CoverCommand): MediaResult<CoverBaseline> = missing()
    open suspend fun openAsset(id: String): MediaResult<StoredImage> = missing()
    open suspend fun removeUnreferenced(): MediaResult<CleanupReport> = missing()

    private fun missing(): MediaResult.Failure = MediaResult.Failure(MediaFailureKind.NOT_FOUND, "Cover media is not implemented yet")
}
