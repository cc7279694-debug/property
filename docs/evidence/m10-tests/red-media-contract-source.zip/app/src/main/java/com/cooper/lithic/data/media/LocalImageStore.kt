package com.cooper.lithic.data.media

import android.content.ContentResolver
import android.net.Uri
import com.cooper.lithic.data.local.LocalMediaAssetEntity
import java.io.File
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers

enum class ImageStoreStage { BEFORE_DECODE, BEFORE_ENCODE, BEFORE_PREPARED_WRITE, BEFORE_FILE_COMMIT }
fun interface ImageStoreFaults {
    fun at(stage: ImageStoreStage)
    companion object { val NONE = ImageStoreFaults { } }
}

/** Missing-behavior boundary for the first real M10 RED run. */
class LocalImageStore(
    private val directory: File,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val faults: ImageStoreFaults = ImageStoreFaults.NONE,
) {
    suspend fun importLocalImage(resolver: ContentResolver, uri: Uri, assetId: String): MediaResult<PreparedImage> = prepareImport(resolver, uri, assetId)
    suspend fun prepareImport(resolver: ContentResolver, uri: Uri, assetId: String): MediaResult<PreparedImage> = missing()
    suspend fun restorePrepared(assetId: String): MediaResult<PreparedImage> = missing()
    suspend fun commitPreparedAsset(prepared: PreparedImage): MediaResult<LocalMediaAssetEntity> = missing()
    suspend fun openAsset(asset: LocalMediaAssetEntity): MediaResult<StoredImage> = missing()
    suspend fun verifyAsset(asset: LocalMediaAssetEntity): MediaResult<StoredImage> = openAsset(asset)
    suspend fun releasePrepared(assetId: String) { }
    suspend fun isPreparedActive(assetId: String): Boolean = false
    suspend fun discardPreparedAsset(assetId: String): MediaResult<Boolean> = missing()
    suspend fun managedAssetsForCleanup(): MediaResult<List<LocalMediaAssetEntity>> = missing()
    suspend fun removeUnreferenced(asset: LocalMediaAssetEntity): MediaResult<Boolean> = missing()
    private fun missing() = MediaResult.Failure(MediaFailureKind.NOT_FOUND, "Local cover storage is not implemented")
}
