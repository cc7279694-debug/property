package com.cooper.lithic.data.media

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File
import java.io.FileNotFoundException
import java.io.OutputStream
import java.util.UUID

/** Test APK only: streams for isolated synthetic fixtures, never real user images. */
class M10ImageSourceProvider : ContentProvider() {
    override fun onCreate() = true
    override fun getType(uri: Uri): String = uri.getQueryParameter("mime") ?: "image/png"
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val access = when (mode) {
            "r" -> ParcelFileDescriptor.MODE_READ_ONLY
            "w", "wt" -> ParcelFileDescriptor.MODE_WRITE_ONLY or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE
            "rw" -> ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_CREATE
            else -> throw FileNotFoundException("Invalid synthetic source access")
        }
        return ParcelFileDescriptor.open(source(uri), access)
    }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val file = source(uri)
        return MatrixCursor(arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)).apply { addRow(arrayOf(file.name, file.length())) }
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = if (source(uri).delete()) 1 else 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
    private fun source(uri: Uri): File {
        val name = uri.lastPathSegment ?: throw FileNotFoundException("Missing synthetic source")
        if (!name.matches(Regex("[a-f0-9-]{36}\\.bin"))) throw FileNotFoundException("Invalid synthetic source")
        val root = File(requireNotNull(context).cacheDir, "m10-synthetic-image-sources")
        if (!root.isDirectory && !root.mkdirs()) throw FileNotFoundException("Cannot create synthetic source directory")
        return File(root, name)
    }
}

data class SyntheticImageSource(val uri: Uri) {
    fun delete(): Boolean = InstrumentationRegistry.getInstrumentation().targetContext.contentResolver.delete(uri, null, null) == 1
    fun write(block: (OutputStream) -> Unit) {
        requireNotNull(InstrumentationRegistry.getInstrumentation().targetContext.contentResolver.openOutputStream(uri, "w")).use(block)
    }
}

object M10ImageSourceFixtures {
    fun source(bytes: ByteArray, mime: String = "image/png"): SyntheticImageSource {
        val uri = Uri.Builder().scheme("content").authority("com.cooper.lithic.m10.testsource").appendPath("${UUID.randomUUID()}.bin").appendQueryParameter("mime", mime).build()
        return SyntheticImageSource(uri).apply { write { it.write(bytes) } }
    }
}
