package com.cooper.lithic.feature.media

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertDoesNotExist
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.cooper.lithic.core.design.LithicTheme
import com.cooper.lithic.core.model.MoneyDirection
import com.cooper.lithic.core.time.FixedBusinessClock
import com.cooper.lithic.data.backup.DataGenerationStore
import com.cooper.lithic.data.backup.ManagedGeneration
import com.cooper.lithic.data.local.CategoryType
import com.cooper.lithic.data.local.LocalMediaAssetEntity
import com.cooper.lithic.data.local.LongTermProjectEntity
import com.cooper.lithic.data.local.ProjectMoneyEventEntity
import com.cooper.lithic.data.local.ProjectMoneyEventRole
import com.cooper.lithic.data.media.CoverBaseline
import com.cooper.lithic.data.media.CoverCommand
import com.cooper.lithic.data.media.M10ImageSourceFixtures
import com.cooper.lithic.data.media.MediaRepository
import com.cooper.lithic.data.media.MediaResult
import com.cooper.lithic.data.media.SyntheticImageSource
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** UI-only preview behavior, backed by a separate real generation and verified media bytes. */
@RunWith(AndroidJUnit4::class)
class UIC1CoverPreviewTest {
    @get:Rule val compose = createComposeRule()
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val date = LocalDate.of(2026, 1, 31)
    private val time = Instant.parse("2026-01-31T03:04:05Z")
    private lateinit var root: File
    private lateinit var generation: ManagedGeneration
    private lateinit var repository: MediaRepository
    private val sources = mutableListOf<SyntheticImageSource>()

    @Before fun setUp() = runBlocking {
        root = File(context.noBackupFilesDir, "ui-c1-cover-${UUID.randomUUID()}")
        generation = DataGenerationStore(context, root).open(ZoneId.of("UTC"))
        repository = MediaRepository(generation.database, generation.coordinator, generation.images,
            FixedBusinessClock(date), context.contentResolver)
    }

    @After fun tearDown() = runBlocking {
        sources.forEach { it.delete() }
        if (::generation.isInitialized) generation.close()
        if (::root.isInitialized) {
            check(root.canonicalFile.parentFile == context.noBackupFilesDir.canonicalFile)
            root.deleteRecursively()
        }
    }

    @Test fun detail_preview_uses_16_by_9_frame_and_retains_original_view_action() {
        val asset = runBlocking { cover(400, 100) }
        compose.setContent { LithicTheme {
            Box(Modifier.width(320.dp)) { CoverDisplay(asset.id, repository, "ui-c1") }
        } }
        awaitImage()
        val bounds = compose.onNodeWithTag("ui-c1-cover-image").fetchSemanticsNode().boundsInRoot
        assertEquals("The detail frame should be 16:9 regardless of source image aspect ratio",
            16f / 9f, bounds.width / bounds.height, 0.01f)
        compose.onNodeWithTag("ui-c1-cover-view").assertIsDisplayed().performClick()
        compose.onNodeWithTag("ui-c1-cover-close").assertIsDisplayed().performClick()
    }

    @Test fun unset_cover_stays_distinct_from_unreadable_referenced_cover() {
        compose.setContent { LithicTheme { CoverDisplay(null, repository, "ui-c1") } }
        compose.onNodeWithTag("ui-c1-cover-empty").assertIsDisplayed()
        compose.onNodeWithTag("ui-c1-cover-error").assertDoesNotExist()
        compose.onNodeWithTag("ui-c1-cover-image").assertDoesNotExist()
    }

    @Test fun corrupt_current_bytes_show_error_and_preserve_reference_and_bytes() {
        val asset = runBlocking { cover(400, 100) }
        val facts = runBlocking { generation.database.projectDao().listProjects() }
        val corrupt = byteArrayOf(1, 2, 3, 4)
        File(generation.directory, asset.relativePath).writeBytes(corrupt)
        compose.setContent { LithicTheme { CoverDisplay(asset.id, repository, "ui-c1") } }
        compose.waitUntil(5_000) {
            compose.onAllNodesWithTag("ui-c1-cover-error").fetchSemanticsNodes().isNotEmpty()
        }
        compose.onNodeWithTag("ui-c1-cover-error").assertIsDisplayed()
        compose.onNodeWithTag("ui-c1-cover-empty").assertDoesNotExist()
        compose.onNodeWithTag("ui-c1-cover-image").assertDoesNotExist()
        runBlocking {
            assertEquals(asset, generation.database.mediaDao().find(asset.id))
            assertEquals(facts, generation.database.projectDao().listProjects())
        }
        assertArrayEquals(corrupt, File(generation.directory, asset.relativePath).readBytes())
    }

    private fun awaitImage() = compose.waitUntil(5_000) {
        compose.onAllNodesWithTag("ui-c1-cover-image").fetchSemanticsNodes().isNotEmpty()
    }

    private suspend fun cover(width: Int, height: Int): LocalMediaAssetEntity {
        val category = generation.database.categoryDao().list().single { it.type == CategoryType.PROJECT }
        val project = LongTermProjectEntity(uuid(), "UI-C1 synthetic cover", category.id, date,
            createdAt = time, updatedAt = time)
        val event = ProjectMoneyEventEntity(uuid(), project.id, MoneyDirection.OUTLAY, 15_000, date,
            "synthetic initial payment", ProjectMoneyEventRole.INITIAL, uuid())
        generation.database.projectDao().insertProject(project)
        generation.database.projectDao().insertEvent(event)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(0xff657f72.toInt())
        val output = ByteArrayOutputStream()
        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output))
        bitmap.recycle()
        val source = M10ImageSourceFixtures.source(output.toByteArray()).also { sources += it }
        val prepared = success(repository.prepareImport(source.uri, uuid()))
        success(repository.commit(CoverCommand(uuid(), CoverBaseline.Project(project, listOf(event)),
            prepared.asset, time.plusSeconds(1))))
        return prepared.asset
    }

    private fun uuid() = UUID.randomUUID().toString()
    private fun <T> success(result: MediaResult<T>): T {
        assertTrue("Expected verified success, got $result", result is MediaResult.Success)
        return (result as MediaResult.Success<T>).value
    }
}
